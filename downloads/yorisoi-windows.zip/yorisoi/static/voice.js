/* Browser speech APIs only. No API keys or raw audio are sent to this server. */
(function (root) {
  'use strict';
  function greetingText(now = new Date()) {
    const hour = now.getHours();
    const hello = hour < 11 ? 'おはようございます' : hour < 18 ? 'こんにちは' : 'こんばんは';
    return `${hello}。よりそいです。今日はどんな一日ですか。体調のことでも、気になることでも、お話しください。`;
  }
  class VoiceController {
    constructor({ Recognition, synth, Utterance, send, status, state, transcript, greeting }) {
      Object.assign(this, { Recognition, synth, Utterance, send, status, state, transcript, greeting });
      this.active = false;
      this.busy = false;
      this.rec = null;
      this.epoch = 0;
      this.readEnabled = true;
      this.greeted = false;
      this.silences = 0;
      this.timer = null;
      this.finishSpeech = null;
    }
    get canSpeak() { return Boolean(this.synth && this.Utterance); }
    update() { this.state({ active: this.active, busy: this.busy, listening: Boolean(this.rec), speaking: Boolean(this.finishSpeech) }); }
    cancelSpeech() {
      if (this.finishSpeech) this.finishSpeech(false);
      if (this.synth) this.synth.cancel();
    }
    pauseRecognition() {
      const rec = this.rec;
      this.rec = null;
      if (rec) { try { rec.abort(); } catch {} }
    }
    stop() {
      this.active = false;
      this.epoch++;
      clearTimeout(this.timer);
      this.pauseRecognition();
      this.cancelSpeech();
      this.status('音声会話を停止しました。マイクは使用していません。');
      this.update();
    }
    say(text) {
      this.pauseRecognition();
      this.cancelSpeech();
      if (!this.canSpeak || !this.readEnabled) return Promise.resolve(false);
      return new Promise(resolve => {
        const utterance = new this.Utterance(text);
        utterance.lang = 'ja-JP';
        utterance.rate = 1;
        const voices = this.synth.getVoices();
        const japanese = voices.find(v => v.lang.toLowerCase().startsWith('ja'));
        if (japanese) utterance.voice = japanese;
        let done = false;
        const finish = success => {
          if (done) return;
          done = true;
          this.finishSpeech = null;
          this.update();
          resolve(success);
        };
        this.finishSpeech = finish;
        utterance.onend = () => finish(true);
        utterance.onerror = () => {
          this.status('読み上げできませんでした。「音声会話を開始」または「挨拶を聞く」を押してください。');
          finish(false);
        };
        this.status('話しています…');
        this.update();
        try { this.synth.speak(utterance); } catch { utterance.onerror(); }
      });
    }
    async greet() {
      const text = greetingText();
      this.greeting(text);
      const token = this.epoch;
      const spoke = await this.say(text);
      if (spoke) this.greeted = true;
      if (token !== this.epoch) return;
      if (!spoke) this.status('「音声会話を開始」を押すとマイクを使えます。挨拶が聞こえない場合は「挨拶を聞く」を押してください。');
      else if (!this.active) this.status('挨拶しました。「音声会話を開始」を押すと、お話を聞きます。');
    }
    async start() {
      if (this.active || this.busy) return;
      if (!this.Recognition) {
        this.status('このブラウザでは音声認識を利用できません。Windows版ChromeまたはEdgeをお試しください。文字入力も利用できます。');
        return;
      }
      this.active = true;
      const token = ++this.epoch;
      this.silences = 0;
      this.update();
      if (!this.greeted && this.readEnabled) await this.greet();
      if (this.active && token === this.epoch) this.listen();
    }
    listen() {
      if (!this.active || this.rec || this.busy || this.finishSpeech) return;
      const rec = new this.Recognition();
      this.rec = rec;
      rec.lang = 'ja-JP';
      rec.continuous = false;
      rec.interimResults = true;
      let final = '';
      rec.onstart = () => { if (this.rec === rec) this.status('聞いています… 話し終えると自動で送信します。'); };
      rec.onresult = event => {
        if (this.rec !== rec || !this.active) return;
        let preview = '';
        final = '';
        for (let i = 0; i < event.results.length; i++) {
          const words = event.results[i][0].transcript;
          preview += words;
          if (event.results[i].isFinal) final += words;
        }
        this.transcript(preview);
      };
      rec.onerror = event => {
        if (this.rec !== rec || !this.active) return;
        if (event.error === 'no-speech') return;
        const errors = {
          'not-allowed': 'マイクが許可されていません。アドレス欄のサイト設定でマイクを許可し、もう一度開始してください。',
          'service-not-allowed': 'ブラウザの音声認識サービスが許可されていません。ブラウザの設定や対応状況を確認してください。',
          'audio-capture': 'マイクが見つかりません。Windowsの入力デバイスとマイクの権限を確認してください。',
          network: '音声認識サービスに接続できません。インターネット接続を確認し、もう一度開始してください。'
        };
        this.stop();
        this.status(errors[event.error] || '音声認識を停止しました。もう一度開始するか、文字入力をご利用ください。');
      };
      rec.onend = () => {
        if (this.rec !== rec) return;
        this.rec = null;
        this.update();
        if (!this.active) return;
        if (final.trim()) { this.silences = 0; void this.ask(final.trim()); }
        else if (++this.silences >= 3) { this.stop(); this.status('音声が聞き取れなかったため停止しました。「音声会話を開始」で再開できます。'); }
        else this.timer = setTimeout(() => this.listen(), 500);
      };
      this.status('マイクを準備しています…');
      this.update();
      try { rec.start(); } catch {
        this.stop();
        this.status('マイクを開始できませんでした。権限を確認してもう一度開始してください。');
      }
    }
    async ask(content) {
      if (this.busy || !content.trim()) return false;
      this.busy = true;
      clearTimeout(this.timer);
      this.pauseRecognition();
      this.cancelSpeech();
      const token = this.epoch;
      this.status('考えています…');
      this.update();
      let success = false;
      try {
        const answer = await this.send(content);
        success = true;
        if (token === this.epoch && this.readEnabled) await this.say(answer);
      } catch (error) {
        this.active = false;
        this.status('応答を取得できませんでした。' + error.message);
      } finally {
        this.busy = false;
        this.update();
        if (token === this.epoch && this.active) this.listen();
        else if (success && token === this.epoch) this.status('お返事しました。「音声会話を開始」で続けて話せます。');
      }
      return success;
    }
    async replayGreeting() {
      if (this.busy) return;
      clearTimeout(this.timer);
      const token = this.epoch;
      await this.greet();
      if (token === this.epoch && this.active) this.listen();
    }
  }
  const exports = { VoiceController, greetingText };
  if (typeof module !== 'undefined' && module.exports) module.exports = exports;
  else root.YorisoiVoice = exports;
})(typeof window === 'undefined' ? globalThis : window);
