const $=id=>document.getElementById(id);
const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text)n.textContent=text;if(cls)n.className=cls;return n;};
async function api(path,body){const r=await fetch('/api/'+path,body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const data=await r.json();if(!r.ok)throw Error(data.error||'通信に失敗しました');return data;}
function empty(node,text){if(!node.children.length)node.append(el('p',text,'empty'));}
function render(s){$('status').textContent=s.ai_connected?'● AI 接続設定あり':'○ 記録モード · API未設定';
$('messages').replaceChildren();for(const m of s.messages){const n=el('div',null,'bubble '+m.role);n.append(el('small',m.role==='user'?'YOU':'よりそい'),document.createTextNode(m.content));$('messages').append(n);}empty($('messages'),'ここは、あなたのための会話スペース。');$('messages').scrollTop=$('messages').scrollHeight;
$('health-list').replaceChildren();for(const h of s.health){const n=el('div',null,'card');n.append(el('small',h.created+' UTC'),el('h2','体調 '+h.mood+' / 5'),el('p',h.note));$('health-list').append(n);}empty($('health-list'),'まだ記録がありません。');
$('memory-list').replaceChildren();for(const m of s.memories){const n=el('div',null,'card row');const controls=el('div');const edit=el('button','編集');edit.onclick=()=>{const content=prompt('記憶を編集',m.content);if(content?.trim())run(()=>api('memory',{id:m.id,content}));};const del=el('button','削除');del.onclick=()=>run(()=>api('memory',{id:m.id,delete:true}));controls.append(edit,del);n.append(el('span',m.content),controls);$('memory-list').append(n);}empty($('memory-list'),'まだ記憶がありません。');
$('news-list').replaceChildren();for(const item of s.news){const n=el('div',null,'card');const a=el('a',item.title);if(new URL(item.url).protocol!=='https:')continue;a.href=item.url;a.target='_blank';a.rel='noopener noreferrer';n.append(a,el('p',item.published,'hint'));$('news-list').append(n);}empty($('news-list'),'テーマを設定してニュースを収集しましょう。');
$('weather-info').replaceChildren();
const weather=s.weather;if(weather?.days?.length){$('weather-info').append(el('h2',weather.area),el('p','発表: '+new Date(weather.reported_at).toLocaleString('ja-JP',{timeZone:'Asia/Tokyo'})+'（日本時間）','hint'),el('p','取得: '+new Date(weather.fetched_at).toLocaleString('ja-JP',{timeZone:'Asia/Tokyo'})+'（日本時間）','hint'));for(const day of weather.days)$('weather-info').append(el('p',new Date(day.time).toLocaleDateString('ja-JP',{timeZone:'Asia/Tokyo'})+' · '+day.weather));if(Date.now()-Date.parse(weather.fetched_at)>7200000)$('weather-info').append(el('p','取得から2時間以上経過しています。更新して確認してください。','hint'));}else $('weather-info').append(el('p','天気はまだ取得していません。','hint'));if(weather?.error)$('weather-info').append(el('p',weather.error,'hint'));
$('regional-topics').value=s.settings.regional_topics||'';
$('topics').value=s.settings.topics;$('automatic').checked=s.settings.automatic==='true';$('remember').checked=s.settings.remember==='true';$('last-collected').textContent=s.settings.last_collected?'最終収集: '+new Date(s.settings.last_collected).toLocaleString():'まだ収集していません。';}
async function run(fn,button){$('notice').textContent='';if(button)button.disabled=true;try{render(await fn());return true;}catch(e){$('notice').textContent=e.message;try{render(await api('state'));}catch{}return false;}finally{if(button)button.disabled=false;}}
for(const b of document.querySelectorAll('[data-tab]'))b.onclick=()=>{document.querySelectorAll('.panel').forEach(n=>n.hidden=n.id!==b.dataset.tab);document.querySelectorAll('[data-tab]').forEach(n=>n.classList.toggle('active',n===b));};
$('chat-form').onsubmit=async e=>{e.preventDefault();const content=$('message').value.trim();if(!content)return;if(await voice.ask(content))$('message').value='';};
$('health-form').onsubmit=async e=>{e.preventDefault();if(await run(()=>api('health',{mood:Number($('mood').value),note:$('health-note').value}),e.submitter))$('health-note').value='';};
$('memory-form').onsubmit=async e=>{e.preventDefault();if(await run(()=>api('memory',{content:$('memory-content').value}),e.submitter))$('memory-content').value='';};
$('news-form').onsubmit=e=>{e.preventDefault();run(()=>api('settings',{topics:$('topics').value,regional_topics:$('regional-topics').value,automatic:String($('automatic').checked)}),e.submitter);};
$('remember').onchange=()=>run(()=>api('settings',{remember:String($('remember').checked)}));
$('weather-refresh').onclick=e=>run(()=>api('weather',{}),e.target);
$('collect').onclick=e=>run(()=>api('collect',{}),e.target);
$('clear').onclick=()=>{if(voice.busy){$('notice').textContent='応答が完了してから削除してください。';return;}if(confirm('会話・体調・記憶・収集記事をすべて削除します。元に戻せません。')){voice.stop();run(()=>api('clear',{}));}};
$('route-form').onsubmit=e=>{e.preventDefault();const p=new URLSearchParams({api:'1',destination:$('destination').value});if($('origin').value.trim())p.set('origin',$('origin').value);window.open('https://www.google.com/maps/dir/?'+p,'_blank','noopener,noreferrer');};
$('search-form').onsubmit=e=>{e.preventDefault();window.open('https://www.google.com/search?'+new URLSearchParams({q:$('query').value}),'_blank','noopener,noreferrer');};
const voice = new YorisoiVoice.VoiceController({
 Recognition: window.SpeechRecognition || window.webkitSpeechRecognition,
 synth: window.speechSynthesis,
 Utterance: window.SpeechSynthesisUtterance,
 send: async content => {
  $('notice').textContent='';
  const s=await api('chat',{content});
  render(s);
  $('voice-transcript').textContent='';
  return s.messages[s.messages.length-1].content;
 },
 status: text => {$('voice-status').textContent=text;},
 greeting: text => {$('voice-greeting').textContent=text;},
 transcript: text => {$('voice-transcript').textContent=text?'聞き取り: '+text:'';},
 state: s => {
  $('voice-start').disabled=!voice.Recognition||s.active||s.busy;
  $('voice-stop').disabled=!(s.active||s.speaking||s.busy);
  $('voice-greet').disabled=s.busy;
  $('chat-form').querySelector('button').disabled=s.busy;
  $('voice-start').textContent=s.active?'● 音声会話中':'🎙 音声会話を開始';
  document.querySelector('.voice-orb').classList.toggle('listening',s.listening);
 }
});
$('voice-start').onclick=()=>voice.start();
$('voice-stop').onclick=()=>voice.stop();
$('voice-greet').onclick=()=>voice.replayGreeting();
$('voice-read').onchange=()=>{voice.readEnabled=$('voice-read').checked;if(!voice.readEnabled)voice.cancelSpeech();};
if(!voice.Recognition){$('text-input').open=true;$('voice-start').disabled=true;}
window.addEventListener('pagehide',()=>voice.stop());
document.addEventListener('visibilitychange',()=>{if(document.hidden)voice.stop();});
run(()=>api('state'));
// Greeting uses a local template, never an API request or automatic microphone access.
voice.greet().then(()=>{if(!voice.Recognition)$('voice-status').textContent='このブラウザでは音声認識を利用できません。Windows版ChromeまたはEdgeをお試しください。文字入力も利用できます。';});
