(function(root){
 'use strict';
 class NaturalSpeaker {
  constructor({fetcher=fetch, AudioClass=Audio, urls=URL, onPlaying=()=>{}}={}){this.fetcher=fetcher;this.AudioClass=AudioClass;this.urls=urls;this.onPlaying=onPlaying;this.current=null;}
  cancel(){if(this.current)this.current();}
  speak(text){
   this.cancel();
   return new Promise(resolve=>{
    const controller=new AbortController();let player=null,url=null,done=false;
    const finish=success=>{if(done)return;done=true;controller.abort();if(player){player.pause();player.removeAttribute('src');player.load();}if(url)this.urls.revokeObjectURL(url);this.current=null;resolve(success);};
    this.current=()=>finish(false);
    (async()=>{
     try{
      const response=await this.fetcher('/api/speech',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text}),signal:controller.signal});
      if(!response.ok)throw Error('Speech API unavailable');
      const blob=await response.blob();if(done)return;
      url=this.urls.createObjectURL(blob);player=new this.AudioClass(url);
      player.onplaying=()=>this.onPlaying();player.onended=()=>finish(true);player.onerror=()=>finish(false);
      await player.play();
     }catch{finish(false);}
    })();
   });
  }
 }
 if(typeof module!=='undefined'&&module.exports)module.exports={NaturalSpeaker};else root.YorisoiAudio={NaturalSpeaker};
})(typeof window==='undefined'?globalThis:window);
