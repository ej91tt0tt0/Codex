/* Browser speech APIs only. No API keys or raw audio are sent to this server. */
(function (root) {
  'use strict';
  function greetingText(now = new Date()) {
    const hour = now.getHours();
    const hello = hour >= 5 && hour < 11 ? 'おはよう' : hour >= 11 && hour < 18 ? 'こんにちは' : 'こんばんは';
    return `${hello}、よりそいだよ。何か話そう。`;
  }
  class VoiceController {
    constructor({ Recognition, synth, Utterance, send, status, state, transcript, greeting, naturalSpeaker = null, proactive = null }) {
      Object.assign(this, { Recognition, synth, Utterance, send, status, state, transcript, greeting, naturalSpeaker, proactive });
      this.idleMilliseconds = 180000;
      this.proactiveEnabled = true;
      this.proactiveCount = 0;
      this.idleTimer = null;
      this.useNatural = true;
      this.resumeAfterInterrupt = false;
      this.active = false;
      this.busy = false;
      this.rec = null;
      this.epoch = 0;
      this.readEnabled = true;
      this.greeted = false;
      this.silences = 0;
      this.timer = null;
      this.finishSpeech = null;
    }
    get canSpeak() { return Boolean((this.synth && this.Utterance) || this.naturalSpeaker); }
    update() { this.state({ active: this.active, busy: this.busy, listening: Boolean(this.rec), speaking: Boolean(this.finishSpeech) }); }
    cancelSpeech() {
      if (this.finishSpeech) this.finishSpeech(false);
      if (this.synth) this.synth.cancel();
      if (this.naturalSpeaker) this.naturalSpeaker.cancel();
    }
    pauseRecognition() {
      const rec = this.rec;
      this.rec = null;
      if (rec) { try { rec.abort(); } catch {} }
    }
    stop() {
      this.active = false;
      this.epoch++;
      clearTimeout(this.timer);
      clearTimeout(this.idleTimer);
      this.resumeAfterInterrupt = false;
      this.pauseRecognition();
      this.cancelSpeech();
      this.status('音声会話を停止しました。マイクは使用していません。');
      this.update();
    }
    say(text) {
      this.pauseRecognition();
      this.cancelSpeech();
      if (!this.canSpeak || !this.readEnabled) return Promise.resolve(false);
      return new Promise(resolve => {
        let done = false;
        const finish = success => {
          if (done) return;
          done = true;
          this.finishSpeech = null;
          this.update();
          resolve(success);
        };
        this.finishSpeech = finish;
        const native = () => {
          if (done) return;
          if (!this.synth || !this.Utterance) { finish(false); return; }
          const utterance = new this.Utterance(text);
          utterance.lang = 'ja-JP'; utterance.rate = 1.12;
          const japanese = this.synth.getVoices().find(v => v.lang.toLowerCase().startsWith('ja'));
          if (japanese) utterance.voice = japanese;
          utterance.onend = () => finish(true);
          utterance.onerror = () => {
            this.status('読み上げできませんでした。「音声会話を開始」または「挨拶を聞く」を押してください。');finish(false);
          };
          try { this.synth.speak(utterance); } catch { utterance.onerror(); }
        };
        this.status('話してるよ…');this.update();
        if (this.naturalSpeaker && this.useNatural) {
          this.status('声を準備中…');
          this.naturalSpeaker.speak(text).then(success => {
            if (done) return;
            if (success) finish(true);
            else { this.status('自然音声を利用できなかったため、ブラウザ音声に切り替えます。');native(); }
          });
        } else native();
      });
    }
    async greet() {
      const text = greetingText();
      this.greeting(text);
      const token = this.epoch;
      const spoke = await this.say(text);
      if (spoke) this.greeted = true;
      if (token !== this.epoch) return;
      if (!spoke) this.status('「音声会話を開始」を押すとマイクを使えます。挨拶が聞こえない場合は「挨拶を聞く」を押してください。');
      else if (!this.active) this.status('挨拶しました。「音声会話を開始」を押すと、お話を聞きます。');
    }
    async start() {
      if (this.active || this.busy) return;
      if (!this.Recognition) {
        this.status('このブラウザでは音声認識を利用できません。Windows版ChromeまたはEdgeをお試しください。文字入力も利用できます。');
        return;
      }
      this.active = true;
      const token = ++this.epoch;
      this.silences = 0;
      this.update();
      if (!this.greeted && this.readEnabled) await this.greet();
      if (this.active && token === this.epoch) { this.listen(); this.armIdle(); }
    }
    listen() {
      if (!this.active || this.rec || this.busy || this.finishSpeech) return;
      const rec = new this.Recognition();
      this.rec = rec;
      rec.lang = 'ja-JP';
      rec.continuous = false;
      rec.interimResults = true;
      let final = '';
      rec.onstart = () => { if (this.rec === rec) this.status('聞いています… 話し終えると自動で送信します。'); };
      rec.onresult = event => {
        if (this.rec !== rec || !this.active) return;
        let preview = '';
        final = '';
        for (let i = 0; i < event.results.length; i++) {
          const words = event.results[i][0].transcript;
          preview += words;
          if (event.results[i].isFinal) final += words;
        }
        this.transcript(preview);
        this.armIdle();
      };
      rec.onerror = event => {
        if (this.rec !== rec || !this.active) return;
        if (event.error === 'no-speech') return;
        const errors = {
          'not-allowed': 'マイクが許可されていません。アドレス欄のサイト設定でマイクを許可し、もう一度開始してください。',
          'service-not-allowed': 'ブラウザの音声認識サービスが許可されていません。ブラウザの設定や対応状況を確認してください。',
          'audio-capture': 'マイクが見つかりません。Windowsの入力デバイスとマイクの権限を確認してください。',
          network: '音声認識サービスに接続できません。インターネット接続を確認し、もう一度開始してください。'
        };
        this.stop();
        this.status(errors[event.error] || '音声認識を停止しました。もう一度開始するか、文字入力をご利用ください。');
      };
      rec.onend = () => {
        if (this.rec !== rec) return;
        this.rec = null;
        this.update();
        if (!this.active) return;
        if (final.trim()) { this.silences = 0; void this.ask(final.trim()); }
        else { this.silences++;this.status('聞いています。お好きなタイミングでお話しください。');this.timer = setTimeout(() => this.listen(), 800); }
      };
      this.status('マイクを準備しています…');
      this.update();
      try { rec.start(); } catch {
        this.stop();
        this.status('マイクを開始できませんでした。権限を確認してもう一度開始してください。');
      }
    }
    async ask(content, { initiative = false, kind = 'thought' } = {}) {
      if (this.busy || (!initiative && !content.trim())) return false;
      clearTimeout(this.idleTimer);
      if (!initiative) this.proactiveCount = 0;
      this.busy = true;
      clearTimeout(this.timer);
      this.pauseRecognition();
      this.cancelSpeech();
      const token = this.epoch;
      this.status('ちょっと考え中…');
      this.update();
      let success = false;
      try {
        const answer = initiative ? await this.proactive(kind) : await this.send(content);
        if (initiative) this.proactiveCount++;
        success = true;
        if (token === this.epoch && this.readEnabled) await this.say(answer);
      } catch (error) {
        this.active = false;
        this.status('応答を取得できませんでした。' + error.message);
      } finally {
        this.busy = false;
        this.update();
        if (this.active && (token === this.epoch || this.resumeAfterInterrupt)) {
          this.resumeAfterInterrupt = false; this.listen(); this.armIdle();
          if (this.proactiveCount >= 3) this.status('自動の声かけを3回行ったため休止します。お話しいただくと再開します。');
        }
        else if (success && token === this.epoch) this.status('お返事しました。「音声会話を開始」で続けて話せます。');
      }
      return success;
    }
    armIdle() {
      clearTimeout(this.idleTimer);
      if (!this.active || !this.proactiveEnabled || !this.proactive || this.proactiveCount >= 3) return;
      this.idleTimer = setTimeout(() => this.initiate(), this.idleMilliseconds);
    }
    initiate() {
      if (!this.active || !this.proactiveEnabled || !this.proactive || this.proactiveCount >= 3) return;
      if (this.busy || this.finishSpeech) { this.armIdle();return; }
      return this.ask('', {initiative:true, kind:this.proactiveCount % 2 ? 'question' : 'thought'});
    }
    interrupt() {
      if (!this.active) return;
      if (this.busy && !this.finishSpeech) { this.status('返答を準備しています。停止ボタンで音声会話を終了できます。');return; }
      this.epoch++;this.silences=0;this.resumeAfterInterrupt=this.busy;
      this.pauseRecognition();this.cancelSpeech();
      if (!this.busy) { this.listen();this.armIdle(); }
    }
    async replayGreeting() {
      if (this.busy) return;
      clearTimeout(this.timer);
      const token = this.epoch;
      await this.greet();
      if (token === this.epoch && this.active) this.listen();
    }
  }
  const exports = { VoiceController, greetingText };
  if (typeof module !== 'undefined' && module.exports) module.exports = exports;
  else root.YorisoiVoice = exports;
})(typeof window === 'undefined' ? globalThis : window);
