const $=id=>document.getElementById(id);
const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text)n.textContent=text;if(cls)n.className=cls;return n;};
async function api(path,body){const r=await fetch('/api/'+path,body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const data=await r.json();if(!r.ok)throw Error(data.error||'通信に失敗しました');return data;}
let currentRequests=[];
function empty(node,text){if(!node.children.length)node.append(el('p',text,'empty'));}
function render(s){$('status').textContent=s.ai_connected?'● 接続済み':'○ 記録モード';
currentRequests=s.improvement_requests||[];
$('improvement-list').replaceChildren();for(const req of currentRequests){const row=el('div',null,'card');row.append(el('small',req.status+' · '+req.created+' UTC'),el('p',req.content));$('improvement-list').append(row);}empty($('improvement-list'),'改善リクエストはまだないよ。');
const lastReply=s.messages.filter(m=>m.role==='assistant').at(-1);$('latest-reply').textContent=lastReply?.content||'';$('latest-reply').hidden=!lastReply;$('voice-greeting').hidden=Boolean(lastReply);
$('messages').replaceChildren();for(const m of s.messages){const n=el('div',null,'bubble '+m.role);n.append(el('small',m.role==='user'?'YOU':'よりそい'),document.createTextNode(m.content));$('messages').append(n);}empty($('messages'),'ここは、あなたのための会話スペース。');$('messages').scrollTop=$('messages').scrollHeight;
$('health-list').replaceChildren();for(const h of s.health){const n=el('div',null,'card');n.append(el('small',h.created+' UTC'),el('h2','体調 '+h.mood+' / 5'),el('p',h.note));$('health-list').append(n);}empty($('health-list'),'まだ記録がありません。');
$('memory-list').replaceChildren();for(const m of s.memories){const n=el('div',null,'card row');const controls=el('div');const edit=el('button','編集');edit.onclick=()=>{const content=prompt('記憶を編集',m.content);if(content?.trim())run(()=>api('memory',{id:m.id,content}));};const del=el('button','削除');del.onclick=()=>run(()=>api('memory',{id:m.id,delete:true}));controls.append(edit,del);n.append(el('span',m.content),controls);$('memory-list').append(n);}empty($('memory-list'),'まだ記憶がありません。');
$('news-list').replaceChildren();for(const item of s.news){const n=el('div',null,'card');const a=el('a',item.title);if(new URL(item.url).protocol!=='https:')continue;a.href=item.url;a.target='_blank';a.rel='noopener noreferrer';n.append(a,el('p',item.published,'hint'));$('news-list').append(n);}empty($('news-list'),'テーマを設定してニュースを収集しましょう。');
$('weather-info').replaceChildren();
const weather=s.weather;if(weather?.days?.length){$('weather-info').append(el('h2',weather.area),el('p','発表: '+new Date(weather.reported_at).toLocaleString('ja-JP',{timeZone:'Asia/Tokyo'})+'（日本時間）','hint'),el('p','取得: '+new Date(weather.fetched_at).toLocaleString('ja-JP',{timeZone:'Asia/Tokyo'})+'（日本時間）','hint'));for(const day of weather.days)$('weather-info').append(el('p',new Date(day.time).toLocaleDateString('ja-JP',{timeZone:'Asia/Tokyo'})+' · '+day.weather));if(Date.now()-Date.parse(weather.fetched_at)>7200000)$('weather-info').append(el('p','取得から2時間以上経過しています。更新して確認してください。','hint'));}else $('weather-info').append(el('p','天気はまだ取得していません。','hint'));if(weather?.error)$('weather-info').append(el('p',weather.error,'hint'));
if(typeof voice!=='undefined'){
 const cfg=s.settings;voice.speechRate=Number(cfg.speech_speed||1.12);$('speech-speed').value=cfg.speech_speed||'1.12';$('speech-register').value=cfg.speech_register||'casual';$('reply-style').value=cfg.reply_style||'normal';$('custom-preferences').value=cfg.custom_preferences||'';
 $('natural-voice').checked=cfg.natural_voice==='true';voice.useNatural=s.ai_connected&&cfg.natural_voice==='true';
 voice.highQualityEnabled=s.ai_connected&&cfg.high_quality_input!=='false';$('high-quality-input').checked=cfg.high_quality_input!=='false';
 const enabled=cfg.proactive_enabled==='true',interval=Number(cfg.proactive_interval||180)*1000;
 if(voice.proactiveEnabled!==enabled||voice.idleMilliseconds!==interval){voice.proactiveEnabled=enabled;voice.idleMilliseconds=interval;voice.armIdle();}
 $('proactive-enabled').checked=enabled;$('proactive-interval').value=String(interval/1000);
}
$('regional-topics').value=s.settings.regional_topics||'';
$('topics').value=s.settings.topics;$('automatic').checked=s.settings.automatic==='true';$('remember').checked=s.settings.remember==='true';$('last-collected').textContent=s.settings.last_collected?'最終収集: '+new Date(s.settings.last_collected).toLocaleString():'まだ収集していません。';}
async function run(fn,button){$('notice').textContent='';if(button)button.disabled=true;try{render(await fn());return true;}catch(e){$('notice').textContent=e.message;try{render(await api('state'));}catch{}return false;}finally{if(button)button.disabled=false;}}
for(const b of document.querySelectorAll('[data-tab]'))b.onclick=()=>{if(b.dataset.tab!=='chat')voice.stop();document.querySelectorAll('.panel').forEach(n=>n.hidden=n.id!==b.dataset.tab);document.querySelectorAll('[data-tab]').forEach(n=>n.classList.toggle('active',n.dataset.tab===b.dataset.tab||(n.id==='menu-button'&&b.dataset.tab!=='chat')));window.scrollTo(0,0);};
$('chat-form').onsubmit=async e=>{e.preventDefault();const content=$('message').value.trim();if(!content)return;if(await voice.ask(content))$('message').value='';};
$('health-form').onsubmit=async e=>{e.preventDefault();if(await run(()=>api('health',{mood:Number($('mood').value),note:$('health-note').value}),e.submitter))$('health-note').value='';};
$('memory-form').onsubmit=async e=>{e.preventDefault();if(await run(()=>api('memory',{content:$('memory-content').value}),e.submitter))$('memory-content').value='';};
$('news-form').onsubmit=e=>{e.preventDefault();run(()=>api('settings',{topics:$('topics').value,regional_topics:$('regional-topics').value,automatic:String($('automatic').checked)}),e.submitter);};
$('remember').onchange=()=>run(()=>api('settings',{remember:String($('remember').checked)}));
$('weather-refresh').onclick=e=>run(()=>api('weather',{}),e.target);
$('collect').onclick=e=>run(()=>api('collect',{}),e.target);
$('clear').onclick=()=>{if(voice.busy){$('notice').textContent='応答が完了してから削除してください。';return;}if(confirm('会話・体調・記憶・収集記事・改善リクエストをすべて削除します。元に戻せません。')){voice.stop();run(()=>api('clear',{}));}};
$('route-form').onsubmit=e=>{e.preventDefault();const p=new URLSearchParams({api:'1',destination:$('destination').value});if($('origin').value.trim())p.set('origin',$('origin').value);window.open('https://www.google.com/maps/dir/?'+p,'_blank','noopener,noreferrer');};
$('search-form').onsubmit=e=>{e.preventDefault();window.open('https://www.google.com/search?'+new URLSearchParams({q:$('query').value}),'_blank','noopener,noreferrer');};
const scope = new YorisoiScope.ScopeView($('voice-scope'),$('input-level'));
const microphone = new YorisoiInput.DuplexInput({
 onStart:()=>voice.hearStart(),
 onText:text=>{if(voice.active){$('voice-transcript').textContent='聞き取り: '+text;void voice.ask(text);}},
 onVolume:(level,spectrum)=>scope.draw(level,spectrum),
 onState:state=>voice.inputState(state),
 onError:message=>{voice.stop();$('voice-status').textContent=message;}
});
const voice = new YorisoiVoice.VoiceController({
 duplexInput: microphone,
 naturalSpeaker: new YorisoiAudio.NaturalSpeaker({onPlaying:()=>{$('voice-status').textContent='話してるよ…';}}),
 proactive: async kind=>{const s=await api('proactive',{kind});render(s);return s.messages[s.messages.length-1].content;},
 Recognition: window.SpeechRecognition || window.webkitSpeechRecognition,
 synth: window.speechSynthesis,
 Utterance: window.SpeechSynthesisUtterance,
 send: async content => {
  $('notice').textContent='';
  const s=await api('chat',{content});
  render(s);
  $('voice-transcript').textContent='';
  return s.messages[s.messages.length-1].content;
 },
 status: text => {$('voice-status').textContent=text;},
 greeting: text => {$('voice-greeting').textContent=text;},
 transcript: text => {$('voice-transcript').textContent=text?'聞き取り: '+text:'';},
 state: s => {
  $('voice-start').disabled=(!voice.Recognition&&!voice.usingDuplex)||s.active||s.busy;
  $('voice-stop').disabled=!(s.active||s.speaking||s.busy);if(!s.listening)$('input-level').textContent='MIC OFF';
  $('voice-greet').disabled=s.busy;
  $('chat-form').querySelector('button').disabled=s.busy;
  $('voice-interrupt').disabled=!s.active||(s.busy&&!s.speaking);
  document.querySelector('.voice-orb').classList.toggle('speaking',s.speaking);
  document.querySelector('.voice-orb').classList.toggle('thinking',s.busy&&!s.speaking);
  $('voice-start').textContent=s.active?'● 音声会話中':'音声会話を開始';
  document.querySelector('.voice-orb').classList.toggle('listening',s.listening);
 }
});
$('voice-start').onclick=()=>voice.start();
$('voice-interrupt').onclick=()=>voice.interrupt();
$('message').addEventListener('input',()=>voice.armIdle());
for(const id of ['natural-voice','proactive-enabled','proactive-interval','high-quality-input'])$(id).onchange=()=>run(()=>api('settings',{high_quality_input:String($('high-quality-input').checked),natural_voice:String($('natural-voice').checked),proactive_enabled:String($('proactive-enabled').checked),proactive_interval:$('proactive-interval').value}));
for(const [id,key] of [['speech-speed','speech_speed'],['speech-register','speech_register'],['reply-style','reply_style']])$(id).onchange=()=>run(()=>api('settings',{[key]:$(id).value}));
$('preferences-form').onsubmit=e=>{e.preventDefault();run(()=>api('settings',{custom_preferences:$('custom-preferences').value}),e.submitter);};
$('export-requests').onclick=()=>{const blob=new Blob([currentRequests.map(r=>'['+r.status+'] '+r.created+' UTC\n'+r.content).join('\n\n')||'改善リクエストはまだないよ。'],{type:'text/plain;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='yorisoi-improvement-requests.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
$('voice-stop').onclick=()=>voice.stop();
$('voice-greet').onclick=()=>{document.querySelector('header [data-tab=chat]').click();voice.replayGreeting();};
$('voice-read').onchange=()=>{voice.readEnabled=$('voice-read').checked;if(!voice.readEnabled)voice.cancelSpeech();};
if(!voice.Recognition&&!voice.usingDuplex){$('text-input').open=true;$('voice-start').disabled=true;}
window.addEventListener('pagehide',()=>voice.stop());
document.addEventListener('visibilitychange',()=>{if(document.hidden)voice.stop();});
// Greeting uses a local template. Natural playback may request TTS; microphone access starts only on user action.
run(()=>api('state')).then(()=>voice.greet()).then(()=>{if(!voice.Recognition&&!voice.usingDuplex){$('text-input').open=true;$('voice-status').textContent='このブラウザでは音声認識を利用できません。Windows版ChromeまたはEdgeをお試しください。文字入力も利用できます。';}});
